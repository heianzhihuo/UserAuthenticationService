create definer = root@localhost trigger tri_insert_user
    after INSERT
    on user
    for each row
begin
    insert into user_account (account_id, account_balance) VALUES (NEW.user_id,'100000');
end;

